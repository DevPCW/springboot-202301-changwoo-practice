package com.study.springboot202301changwoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot202301ChangwooApplicationTests {

	@Test
	void contextLoads() {
	}

}
